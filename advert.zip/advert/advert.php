<?php
/*
Plugin Name:Advertisement
Description:Advertisement DISPLAYER
Version: 1.0
Author: WHO CARES
Author URI:https://URI_Of_The_Plugin_Author
License:A "Slug" license name e.g.:GPL2
.
Any other notes about the plugin go here
.
*/
add_action('admin_menu', 'blog_menu');
 
function blog_menu(){
        add_menu_page( 'ADVERTISEMENT', 'Advertisement Displayer', 'manage_options', 'advert-plugin', 'display_settings' );
}

function adverts() {   
    $args = array(
      'public' => true,
      'label'  => 'Advertisement',
      'has_archive'=>true,
      'supports' => array('title', 'author','editor','thumbnail','custom-fields')
    );
    register_post_type( 'ads', $args );
}
add_action( 'init', 'adverts' );
add_theme_support('post-thumbnails');


function display_settings(){

	$args = array('post_type'=>'ads','numberposts'=>-1,'post_status'=>'publish','order'=>'DESC');
	$posts=get_posts($args);
	// var_dump($posts);
	foreach ($posts as $adverts) 
	{
		$id=$adverts->ID;
		$ad_title=$adverts->post_title;
		$image=get_the_post_thumbnail($id,array('150px','150px'));
		// var_dump($image);
	?>
	<div class="advert">
	<form method="POST" action="" class="advert_table">
		<table>
			<tr>
				<th>Ad Name</th>
				<th>Ad Image</th>
				<th>Enable</th>
				<th>Disable</th>
			</tr>
			<tr>
				<td><?php echo $ad_title;?></td>
				<td><?php echo $image;?></td>
				<td><input type="checkbox" id='yes' class="rad" value="<?php echo $id;?>" name="optradio"></td>
				<td><input type="checkbox" id='no' class="rad" value="no" name="optradio"></td>
				<td><input type="hidden" name="id" class="adid" value="<?php echo $id;?>">
			</tr>
			
		</table>
	
	<?php
	}
	?>
	<div class='form-block-submit'><input type="submit" name="submit" value="Generate"></div>
	<div class='cust_shortcode'><span class="short"></span></div>
	</form>
	</div>
		<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery(".advert_table").submit(function(e){
			var radiovalue = jQuery("input[name='optradio']:checked").val();
			// alert(radiovalue);
			// var ad_id = jQuery(".adid").val();
			var p=[];
                        jQuery('input.rad').each( function() {
                                if(jQuery(this).attr('checked')) {
                                        p.push(jQuery(this).val());
                                }
                        } );
			 alert(p.toString());
			jQuery.ajax({
				type:'POST',
				url:"<?php echo content_url().'/plugins/advert/ajax-advert-submit.php';?>",

				data:{radioo:radiovalue, p:p.toString()},
				success:function(data){
					// alert(data);
					var result = jQuery.parseJSON(data);
	            	//alert(result);
	            	jQuery('.short').text(result);
				}
			});
			e.preventDefault();
			});
	});

		</script>

	<?php
	// }
	// else if ($selected_radio == 'no') {

	// 	echo "HEEYY"

	// 	}
	}
    ?>
   <?php
  
  function addisplay($atts){

	$dirname = dirname(__FILE__);
	$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;
	require_once( $root . "wp-config.php" );
	$atts = shortcode_atts(array('id'=>''), $atts,'adverts');
	$rena = $atts['id'];
	// echo $rena;
	// $exp = explode(",",$rena);
	// $in = $exp[0];
	// $int = (int)$in;

	$args = array('post_type'=>'ads','numberposts'=>-1,'post_status'=>'publish','order'=>'DESC');
	$posts=get_posts($args);
	// var_dump( $posts);
	// var_dump($posts);
	foreach ($posts as $advertss) 
	{
		$id=$advertss->ID;
		$ad_title=$advertss->post_title;
		$image=get_the_post_thumbnail($id);
		$return = '<div class="col-md-6">
				  <div class="blog-block">
				    <div class="blog-page-heading">                
                    <h3 class="blog-title"><a href="" class="black">'.$ad_title.'</a></h2>
                   </div>
                  <div class="blog-banner-img">
                    <img src="'.get_the_post_thumbnail_url($id).'" class="img-responsive" alt="Blog" />
                  </div>
                  <div class="blog-content">
                      <p>'.$contents.'</p>
                  </div>
              </div>
            </div>';
        $html .= $return;
    }
	return $html;
?>
</div>

	

<?php
}
add_shortcode('adverts', 'addisplay');
?>