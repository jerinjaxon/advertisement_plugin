<?php
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
$radioo=$_POST['radioo'];
// echo $radioo;
$aid =$_POST['p'];
echo json_decode($aid);
$shortcode='[adverts id="'.$aid.'"]';
// $shortcode = '[popup id="1"]';
echo json_encode($shortcode);
 ?>